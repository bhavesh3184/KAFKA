/* Licensed under Apache-2.0 */
package kopoa.smt.migrate.schema;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.apache.kafka.common.cache.Cache;
import org.apache.kafka.common.cache.LRUCache;
import org.apache.kafka.common.cache.SynchronizedCache;
import org.apache.kafka.common.config.ConfigDef;
import org.apache.kafka.common.errors.SerializationException;
import org.apache.kafka.connect.connector.ConnectRecord;
import org.apache.kafka.connect.data.Schema;
import org.apache.kafka.connect.errors.ConnectException;
import org.apache.kafka.connect.transforms.Transformation;
import org.apache.kafka.connect.transforms.util.NonEmptyListValidator;
import org.apache.kafka.connect.transforms.util.SimpleConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.confluent.kafka.schemaregistry.ParsedSchema;
import io.confluent.kafka.schemaregistry.client.CachedSchemaRegistryClient;
import io.confluent.kafka.schemaregistry.client.SchemaRegistryClientConfig;
import io.confluent.kafka.schemaregistry.client.rest.exceptions.RestClientException;
import io.confluent.kafka.schemaregistry.protobuf.ProtobufSchemaProvider;
import io.confluent.kafka.serializers.subject.TopicNameStrategy;
import io.confluent.kafka.serializers.subject.strategy.SubjectNameStrategy;


@SuppressWarnings("unused")
public class SchemaRegistryTransfer<R extends ConnectRecord<R>> implements Transformation<R> {
    public static final String OVERVIEW_DOC = "Inspect the Confluent KafkaAvroSerializer's wire-format header to copy schemas from one Schema Registry to another.";
    private static final Logger log = LoggerFactory.getLogger(SchemaRegistryTransfer.class);

    private static final byte MAGIC_BYTE = (byte) 0x0;
    // wire-format is magic byte + an integer, then data
    private static final short WIRE_FORMAT_PREFIX_LENGTH = 1 + (Integer.SIZE / Byte.SIZE);

    public static final ConfigDef CONFIG_DEF;
    public static final String SCHEMA_CAPACITY_CONFIG_DOC = "The maximum amount of schemas to be stored for each Schema Registry client.";
    public static final Integer SCHEMA_CAPACITY_CONFIG_DEFAULT = 200;

    public static final String SRC_PREAMBLE = "For source consumer's schema registry, ";
    public static final String SRC_SCHEMA_REGISTRY_CONFIG_DOC = "A list of addresses for the Schema Registry to copy from. The consumer's Schema Registry.";

    public static final String DEST_PREAMBLE = "For target producer's schema registry, ";
    public static final String DEST_SCHEMA_REGISTRY_CONFIG_DOC = "A list of addresses for the Schema Registry to copy to. The producer's Schema Registry.";

    public static final String TRANSFER_KEYS_CONFIG_DOC = "Whether or not to copy message key schemas between registries.";
    public static final Boolean TRANSFER_KEYS_CONFIG_DEFAULT = true;
    public static final String INCLUDE_HEADERS_CONFIG_DOC = "Whether or not to preserve the Kafka Connect Record headers.";
    public static final Boolean INCLUDE_HEADERS_CONFIG_DEFAULT = true;
    public static final String UPDATE_COMPATIBILITY_CONFIG_DOC = "Update Compatibility to 'NONE'.";
    public static final Boolean UPDATE_COMPATIBILITY_CONFIG_DEFAULT = false;

    private CachedSchemaRegistryClient sourceSchemaRegistryClient;
    private CachedSchemaRegistryClient destSchemaRegistryClient;
    private TopicNameStrategy subjectNameStrategy;
    private boolean transferKeys, includeHeaders, updateCompatibility;

    // caches from the source registry to the destination registry
    private Cache<SchemaKey, SchemaAndId> schemaCache;

    public SchemaRegistryTransfer() {
    }

    static {
        CONFIG_DEF = (new ConfigDef())
                .define(ConfigName.SRC_SCHEMA_REGISTRY_URL, ConfigDef.Type.LIST, ConfigDef.NO_DEFAULT_VALUE, new NonEmptyListValidator(), ConfigDef.Importance.HIGH, SRC_SCHEMA_REGISTRY_CONFIG_DOC)
                .define(ConfigName.DEST_SCHEMA_REGISTRY_URL, ConfigDef.Type.LIST, ConfigDef.NO_DEFAULT_VALUE, new NonEmptyListValidator(), ConfigDef.Importance.HIGH, DEST_SCHEMA_REGISTRY_CONFIG_DOC)
                .define(ConfigName.SCHEMA_CAPACITY, ConfigDef.Type.INT, SCHEMA_CAPACITY_CONFIG_DEFAULT, ConfigDef.Importance.LOW, SCHEMA_CAPACITY_CONFIG_DOC)
                .define(ConfigName.TRANSFER_KEYS, ConfigDef.Type.BOOLEAN, TRANSFER_KEYS_CONFIG_DEFAULT, ConfigDef.Importance.MEDIUM, TRANSFER_KEYS_CONFIG_DOC)
                .define(ConfigName.INCLUDE_HEADERS, ConfigDef.Type.BOOLEAN, INCLUDE_HEADERS_CONFIG_DEFAULT, ConfigDef.Importance.MEDIUM, INCLUDE_HEADERS_CONFIG_DOC)
                .define(ConfigName.UPDATE_COMPATIBILITY, ConfigDef.Type.BOOLEAN, UPDATE_COMPATIBILITY_CONFIG_DEFAULT,ConfigDef.Importance.MEDIUM, UPDATE_COMPATIBILITY_CONFIG_DOC)
        ;
        // TODO: Other properties might be useful, e.g. the Subject Strategies
    }

    @Override
    public ConfigDef config() {
        return CONFIG_DEF;
    }

    @Override
    public void configure(Map<String, ?> props) {
        SimpleConfig config = new SimpleConfig(CONFIG_DEF, props);

        List<String> sourceUrls = config.getList(ConfigName.SRC_SCHEMA_REGISTRY_URL);
        final Map<String, Object> sourceProps = new HashMap<>();

        for (Map.Entry<String, ?> entry : props.entrySet()) {
            if (entry.getKey().startsWith(ConfigName.SRC_CLIENT_CONFIG_PREFIX)) {
                sourceProps.put(entry.getKey().substring(ConfigName.SRC_CLIENT_CONFIG_PREFIX.length()), entry.getValue());
            }
        }

        List<String> destUrls = config.getList(ConfigName.DEST_SCHEMA_REGISTRY_URL);
        final Map<String, Object> destProps = new HashMap<>();

        for (Map.Entry<String, ?> entry : props.entrySet()) {
            if (entry.getKey().startsWith(ConfigName.DEST_CLIENT_CONFIG_PREFIX)) {
                destProps.put(entry.getKey().substring(ConfigName.DEST_CLIENT_CONFIG_PREFIX.length()), entry.getValue());
            }
        }

        Integer schemaCapacity = config.getInt(ConfigName.SCHEMA_CAPACITY);

        this.schemaCache = new SynchronizedCache<>(new LRUCache<>(schemaCapacity));
        this.sourceSchemaRegistryClient = new CachedSchemaRegistryClient(sourceUrls, schemaCapacity, List.of(new ProtobufSchemaProvider()), sourceProps);
        this.destSchemaRegistryClient = new CachedSchemaRegistryClient(destUrls, schemaCapacity, List.of(new ProtobufSchemaProvider()), destProps);

        this.transferKeys = config.getBoolean(ConfigName.TRANSFER_KEYS);
        this.includeHeaders = config.getBoolean(ConfigName.INCLUDE_HEADERS);
        this.updateCompatibility = config.getBoolean(ConfigName.UPDATE_COMPATIBILITY);

        // TODO: Make the Strategy configurable, may be different for src and dest
        // Strategy for the -key and -value subjects
        this.subjectNameStrategy = new TopicNameStrategy();
    }

    @Override
    public R apply(R r) {
        final String topic = r.topic();

        // Transcribe the key's schema id
        final Object key = r.key();
        final Schema keySchema = r.keySchema();

        Object updatedKey = key;
        Optional<Integer> destKeySchemaId;
        if (transferKeys) {
            if (ConnectSchemaUtil.isBytesSchema(keySchema) || key instanceof byte[]) {
                if (key == null) {
                    log.debug("Passing through null record key.");
                } else {
                    byte[] keyAsBytes = (byte[]) key;
                    int keyByteLength = keyAsBytes.length;
                    if (keyByteLength <= 5) {
                        throw new SerializationException("Unexpected byte[] length " + keyByteLength + " for Avro record key.");
                    }
                    ByteBuffer b = ByteBuffer.wrap(keyAsBytes);
                    destKeySchemaId = copySchema(b, topic, true);
                    b.putInt(1, destKeySchemaId.orElseThrow(()
                            -> new ConnectException("Transform failed. Unable to update record schema id. (isKey=true)")));
                    updatedKey = b.array();
                }
            } else {
                throw new ConnectException("Transform failed. Record key does not have a byte[] schema.");
            }
        } else {
            log.debug("Skipping record key translation. {} has been to false. Keys will be passed as-is."
                    , ConfigName.TRANSFER_KEYS);
        }

        // Transcribe the value's schema id
        final Object value = r.value();
        final Schema valueSchema = r.valueSchema();

        Object updatedValue = value;
        Optional<Integer> destValueSchemaId;
        if (ConnectSchemaUtil.isBytesSchema(valueSchema) || value instanceof byte[]) {
            if (value == null) {
                log.debug("Passing through null record value");
            } else {
                byte[] valueAsBytes = (byte[]) value;
                int valueByteLength = valueAsBytes.length;
                if (valueByteLength <= 5) {
                    throw new SerializationException("Unexpected byte[] length " + valueByteLength + " for Avro record value.");
                }
                ByteBuffer b = ByteBuffer.wrap(valueAsBytes);
                destValueSchemaId = copySchema(b, topic, false);
                b.putInt(1, destValueSchemaId.orElseThrow(()
                        -> new ConnectException("Transform failed. Unable to update record schema id. (isKey=false)")));
                updatedValue = b.array();
            }
        } else {
            throw new ConnectException("Transform failed. Record value does not have a byte[] schema.");
        }


        return includeHeaders ?
                r.newRecord(topic, r.kafkaPartition(),
                        keySchema, updatedKey,
                        valueSchema, updatedValue,
                        r.timestamp(),
                        r.headers())
                :
                r.newRecord(topic, r.kafkaPartition(),
                        keySchema, updatedKey,
                        valueSchema, updatedValue,
                        r.timestamp());
    }

    protected Optional<Integer> copySchema(ByteBuffer buffer, String topic, boolean isKey) {
        SchemaAndId schemaAndDestId;
        if (buffer.get() == MAGIC_BYTE) {
            int sourceSchemaId = buffer.getInt();
            log.debug("Source Schmea ID is {}", sourceSchemaId);
            String targetSubjectName = subjectNameStrategy.subjectName(topic, isKey, null);
            schemaAndDestId = schemaCache.get(new SchemaKey(sourceSchemaId, targetSubjectName));
            if (schemaAndDestId != null) {
                log.debug("Schema id {} has been seen before. Not registering with destination registry again.");
            } else { // cache miss
                log.debug("Schema id {} has not been seen before", sourceSchemaId); 
                schemaAndDestId = new SchemaAndId();
                try {
                    log.debug("Looking up schema id {} in source registry", sourceSchemaId);
                    // Can't do getBySubjectAndId because that requires a Schema object for the strategy
                    schemaAndDestId.schema = sourceSchemaRegistryClient.getSchemaById(sourceSchemaId);
                } catch (IOException | RestClientException e) {
                    log.error(String.format("Unable to fetch source schema for id %d.", sourceSchemaId), e);
                    throw new ConnectException(e);
                }

                try {
                    log.debug("Registering schema {} to destination registry", schemaAndDestId.schema);
                    // It could be possible that the destination naming strategy is different from the source
                    schemaAndDestId.id = destSchemaRegistryClient.register(targetSubjectName, schemaAndDestId.schema);
                    if (updateCompatibility){
                        destSchemaRegistryClient.updateCompatibility(targetSubjectName, "NONE");
                    }
                    schemaAndDestId.subjectName = targetSubjectName;
                    log.debug("Destination Schmea ID is {}", schemaAndDestId.id);
                    schemaCache.put(new SchemaKey(sourceSchemaId, targetSubjectName), schemaAndDestId);
                } catch (IOException | RestClientException e) {
                    log.error(String.format("Unable to register source schema id %d to destination registry.",
                            sourceSchemaId), e);
                    return Optional.empty();
                }
            }
        } else {
            throw new SerializationException("Unknown magic byte!");
        }
        return Optional.ofNullable(schemaAndDestId.id);
    }

    @Override
    public void close() {
        this.sourceSchemaRegistryClient = null;
        this.destSchemaRegistryClient = null;
    }

    interface ConfigName {
        String SRC_SCHEMA_REGISTRY_URL = "src.url";
        String SRC_CLIENT_CONFIG_PREFIX = "src.client.";
        String DEST_CLIENT_CONFIG_PREFIX = "dest.client.";
        String SRC_BASIC_AUTH_CREDENTIALS_SOURCE = "src." + SchemaRegistryClientConfig.BASIC_AUTH_CREDENTIALS_SOURCE;
        String SRC_USER_INFO = "src." + SchemaRegistryClientConfig.USER_INFO_CONFIG;
        String DEST_SCHEMA_REGISTRY_URL = "dest.url";
        String DEST_BASIC_AUTH_CREDENTIALS_SOURCE = "dest." + SchemaRegistryClientConfig.BASIC_AUTH_CREDENTIALS_SOURCE;
        String DEST_USER_INFO = "dest." + SchemaRegistryClientConfig.USER_INFO_CONFIG;
        String SCHEMA_CAPACITY = "schema.capacity";
        String TRANSFER_KEYS = "transfer.message.keys";
        String INCLUDE_HEADERS = "include.message.headers";
        String UPDATE_COMPATIBILITY = "update.compatibility";
    }

    private static class SchemaKey{
        private Integer sourceSchemaId;
        private String targetSubjectName;

        

        public SchemaKey(Integer id, String subjectName) {
            this.sourceSchemaId = id;
            this.targetSubjectName = subjectName;
        }
        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((sourceSchemaId == null) ? 0 : sourceSchemaId.hashCode());
            result = prime * result + ((targetSubjectName == null) ? 0 : targetSubjectName.hashCode());
            return result;
        }
        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            SchemaKey other = (SchemaKey) obj;
            if (sourceSchemaId == null) {
                if (other.sourceSchemaId != null)
                    return false;
            } else if (!sourceSchemaId.equals(other.sourceSchemaId))
                return false;
            if (targetSubjectName == null) {
                if (other.targetSubjectName != null)
                    return false;
            } else if (!targetSubjectName.equals(other.targetSubjectName))
                return false;
            return true;
        }
        @Override
        public String toString() {
            return "SchemaKey [id=" + sourceSchemaId + ", subjectName=" + targetSubjectName + "]";
        }
        
    }

    private static class SchemaAndId {
        private Integer id;
        private ParsedSchema schema;
        private String subjectName;

        SchemaAndId() {
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((id == null) ? 0 : id.hashCode());
            result = prime * result + ((schema == null) ? 0 : schema.hashCode());
            result = prime * result + ((subjectName == null) ? 0 : subjectName.hashCode());
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            SchemaAndId other = (SchemaAndId) obj;
            if (id == null) {
                if (other.id != null)
                    return false;
            } else if (!id.equals(other.id))
                return false;
            if (schema == null) {
                if (other.schema != null)
                    return false;
            } else if (!schema.equals(other.schema))
                return false;
            if (subjectName == null) {
                if (other.subjectName != null)
                    return false;
            } else if (!subjectName.equals(other.subjectName))
                return false;
            return true;
        }

        @Override
        public String toString() {
            return "SchemaAndId [id=" + id + ", schema=" + schema + ", subjectName=" + subjectName + "]";
        }

      
    }

}
